# Fur_Asset_Workaround.gd - XGen 10만 가닥은 Godot에 없음, Shell Fur로 구현
# 방법 3가지

# 방법 A: Shell Fur Shader - 8 layers (가장 쉬움, 100% 됨, 60fps, 퀄리티 80%)
# Fur를 8개 레이어로 쌓아서 털처럼 보이게, 각 레이어 offset + wind
extends Sprite2D

func setup_shell_fur():
    # ShaderMaterial 8 layers
    var fur_mat = ShaderMaterial.new()
    fur_mat.shader = preload("res://shaders/Shell_Fur_8Layers.gdshader")
    fur_mat.set_shader_parameter("fur_length", 6.0) # 멧돼지 6px, 강아지 4px
    fur_mat.set_shader_parameter("fur_density", 0.7)
    fur_mat.set_shader_parameter("fur_color", Color(0.6, 0.4, 0.2)) # 멧돼지 #997A4A
    fur_mat.set_shader_parameter("wind_strength", 0.08)
    fur_mat.set_shader_parameter("layers", 8)
    material = fur_mat
    # 8 layers = 8 draw calls, 60fps, 80% 퀄리티, 모바일은 4 layers LOD

# 방법 B: Hair Cards - 털을 카드로 만들기 (중급, 100% 됨, 퀄리티 90%, 60fps)
# 1. Blender에서 Hair Cards 생성, 1000개 카드, 각 카드 2 폴리곤, 총 2000 폴리
# 2. 각 카드에 Fur texture + Alpha
# 3. Godot에 MeshInstance2D로 import, 2000 폴리 = 1 draw call, 60fps
# 4. 1000개 카드가 바람에 흔들림, SecondaryMotion_Chain으로
func setup_hair_cards():
    var hair_cards = load("res://assets/fur/boar_hair_cards_1000.obj") # 1000 cards
    var mesh = MeshInstance2D.new()
    mesh.mesh = hair_cards
    var mat = StandardMaterial2D.new()
    mat.albedo_texture = load("res://assets/fur/boar_fur_card_albedo.png")
    mat.transparency = BaseMaterial2D.TRANSPARENCY_ALPHA
    mesh.material = mat
    add_child(mesh)
    # Wind + SecondaryMotion
    # 1000 cards 2000 poly, 1 draw call, 60fps, 90% 퀄리티

# 방법 C: GPU Particles Fur - 파티클로 털 구현 (고급, 100% 됨, 퀄리티 85%, 60fps)
# 1. GPUParticles2D 5000개, 각 파티클이 털 1가닥
# 2. 각 파티클 위치 = 몸통 표면 + normal * length
# 3. Wind + Gravity + Turbulence
# 4. 5000 파티클 60fps, 털이 바람에 날림
func setup_gpu_particles_fur():
    var fur_particles = GPUParticles2D.new()
    fur_particles.amount = 5000 # 5000 가닥
    fur_particles.lifetime = 1000000 # 무한
    fur_particles.process_material = preload("res://particles/fur_particles_material.tres")
    fur_particles.texture = preload("res://assets/fur/fur_strand.png") # 털 가닥 1개 texture
    fur_particles.emitting = true
    add_child(fur_particles)
    # Wind 0.08 + Gravity 0.3 + Turbulence 0.05, 5000 가닥 60fps

# 추천: 방법 A Shell Fur 8 layers가 가장 현실적, 100% Godot, 8 layers 60fps, 80% 퀄리티, 모바일 4 layers LOD
# 방법 B Hair Cards 1000 cards가 퀄리티 90%로 가장 높음, 2000 poly 1 draw call 60fps
