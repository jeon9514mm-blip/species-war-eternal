# Texture_32K_Workaround.gd - Godot 최대 8K(8192)까지만 지원, 32K는 타일링으로 구현
# 방법 3가지

# 방법 A: 32K를 8K 16개 타일로 나누기 (가장 쉬움, 100% 됨, 60fps)
# 32768x32768 = 8K(8192) 4x4 = 16개 타일, 각 타일 8K 10MB, 총 160MB but streaming
extends Node2D

var tiles = [] # 16개 TileMap or Sprite2D
var tile_size = 8192

func setup_32k_tiled():
    # 32K albedo.png를 8K 16개로 자르기 - Python PIL로
    # from PIL import Image; img = Image.open("stone_32K_albedo.png"); for y in 0..3, x in 0..3: crop and save
    # Godot에서 16개 Sprite2D로 배치, 카메라 가까운 타일만 로드
    for y in range(4):
        for x in range(4):
            var tile = Sprite2D.new()
            tile.texture = load("res://textures/stone_32K_albedo_tile_%d_%d_8K.png" % [x, y])
            tile.position = Vector2(x * tile_size, y * tile_size)
            tile.visible = false # LOD, 카메라 가까울 때만 visible
            add_child(tile)
            tiles.append(tile)
    
    # LOD - 카메라 거리 300px 이내 타일만 visible
    # 16개 중 4개만 visible, 메모리 40MB, 60fps

func _process(delta):
    var cam_pos = get_viewport().get_camera_2d().global_position
    for tile in tiles:
        var dist = cam_pos.distance_to(tile.global_position)
        tile.visible = dist < 500 # 500px 이내만

# 방법 B: Virtual Texture Streaming (Godot 4.4 + custom shader, 80% 됨, 고급)
# 1. 32K를 512x512 타일 64x64 = 4096개 타일로 나누기
# 2. Shader에서 UV에 따라 필요한 타일만 로드, 4096개 중 16개만 메모리
# 3. Custom shader + GDScript로 streaming, 100MB 메모리로 32K 효과
# 4. Godot addons/virtual_texture/ plugin 필요, 구현 3일
func setup_virtual_texture():
    var vt_shader = preload("res://shaders/Virtual_Texture_32K.gdshader")
    var mat = ShaderMaterial.new()
    mat.shader = vt_shader
    mat.set_shader_parameter("tile_size", 512)
    mat.set_shader_parameter("atlas_tiles", 64) # 64x64 = 4096 tiles
    mat.set_shader_parameter("streaming_tiles", 16) # 16 tiles only in memory
    $TileMap.material = mat
    # Shader에서 UV -> tile index -> load tile texture

# 방법 C: 8K로 다운스케일 + Detail Map (현실적, 100% 됨, 60fps, 퀄리티 90%)
# 32K -> 8K로 RealESRGAN 8x가 아니라 4x 다운스케일, 8K 8192x8192로 Godot import
# + Detail Map 2K로 micro detail 추가, 8K + 2K detail = 32K처럼 보임
# 8K 10MB + 2K detail 2MB = 12MB, 32K 1GB보다 80배 작고 90% 퀄리티
func setup_8k_plus_detail():
    var mat = ShaderMaterial.new()
    mat.shader = preload("res://shaders/PBR_8K_Plus_Detail.gdshader")
    mat.set_shader_parameter("albedo_8K", load("res://textures/stone_8K_albedo.png")) # 8K
    mat.set_shader_parameter("detail_2K", load("res://textures/stone_2K_detail.png")) # 2K detail, 0.5px
    mat.set_shader_parameter("normal_8K", load("res://textures/stone_8K_normal.png"))
    mat.set_shader_parameter("ao_4K", load("res://textures/stone_4K_ao.png"))
    $TileMap.material = mat
    # Shader에서 albedo_8K * detail_2K, 8K + detail = 32K처럼 보임, 90% 퀄리티, 60fps

# 추천: 방법 C가 가장 현실적, 100% Godot, 8K + 2K detail = 32K처럼, 12MB, 60fps, 퀄리티 90%
