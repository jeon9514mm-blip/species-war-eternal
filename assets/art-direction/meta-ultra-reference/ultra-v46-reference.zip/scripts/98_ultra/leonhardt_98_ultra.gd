# 레온하르트 베일 (leonhardt) - 98점 울트라 디테일 - Hair 600 + Cloth 5점 + PBR Micro + Trail 0.40s + Particles 40개 + Impact 1.8 + Damage 18px + Shake 10px + HitStop 0.18s
extends Node

const HERO = "leonhardt"
const ULTRA = {
    "hair_cards": 600, "hair_anisotropic": true, "hair_sss": 0.25, "hair_rim": 0.25, "hair_wind": 0.15, "hair_clump": 0.3, "hair_frizz": 0.1,
    "cloth_points": 5, "cloth_stiffness": 0.12, "cloth_damping": 0.88, "cloth_wind": 0.12, "cloth_collision": true,
    "pbr_moss": 0.18, "pbr_patine": 0.25, "pbr_edge_wear": 0.8, "pbr_micro_normal": true, "pbr_triplanar": true, "pbr_parallax": true, "pbr_height": 0.08, "pbr_sss": 0.25, "pbr_rim": 0.25, "pbr_ao": 0.7,
    "trail": 0.40, "after_image": 5, "chromatic": 0.05, "motion_blur": true, "light_trail": true, "shadow_trail": true,
    "particles": 40, "sub_particles": 20, "gpu": true, "collision": true, "light": true, "shadow": true, "turbulence": true,
    "impact_scale": 1.8, "glow": 0.9, "bloom": 0.7, "screen_flash": 0.18, "shake": 10.0, "hitstop": 0.18, "slowmo": 0.08,
    "damage_size": 18, "damage_outline": 3.0, "damage_scale": 1.5, "damage_y": -48, "damage_duration": 0.80,
}

func get_ultra(slot: String) -> Dictionary:
    match slot:
        "passive":
            return {"hero": HERO, "skill": "꺾이지 않는 기치", "slot": "passive", "ultra": ULTRA, "elements": ["꺾이지 않는 기치 ultra - Hair 600 + Cloth 5점 + Trail 0.40s + Particles 40개 + Impact 1.8 + Glow 0.9 + Bloom 0.7 + Flash 0.18 + Shake 10px + HitStop 0.18s + Damage 18px"]}
        "a1":
            return {"hero": HERO, "skill": "철벽 방패", "slot": "a1", "ultra": ULTRA, "elements": ["철벽 방패 ultra - Hair 600 + Cloth 5점 + Trail 0.40s + Particles 40개 + Impact 1.8 + Glow 0.9 + Bloom 0.7 + Flash 0.18 + Shake 10px + HitStop 0.18s + Damage 18px"]}
        "a2":
            return {"hero": HERO, "skill": "동료의 방벽", "slot": "a2", "ultra": ULTRA, "elements": ["동료의 방벽 ultra - Hair 600 + Cloth 5점 + Trail 0.40s + Particles 40개 + Impact 1.8 + Glow 0.9 + Bloom 0.7 + Flash 0.18 + Shake 10px + HitStop 0.18s + Damage 18px"]}
        "ultimate":
            return {"hero": HERO, "skill": "왕국의 마지막 성벽", "slot": "ultimate", "ultra": ULTRA, "elements": ["왕국의 마지막 성벽 ultra - Hair 600 + Cloth 5점 + Trail 0.40s + Particles 40개 + Impact 1.8 + Glow 0.9 + Bloom 0.7 + Flash 0.18 + Shake 10px + HitStop 0.18s + Damage 18px"]}
        _: return {}
