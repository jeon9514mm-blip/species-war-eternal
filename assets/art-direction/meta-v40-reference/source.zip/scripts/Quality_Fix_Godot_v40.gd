# Quality_Fix_Godot_v40.gd - 이따구 품질 나온 이유 + 고치는 코드, 100% Godot 4.4 작동
# 사진 분석: 석판 흐림 + 영웅 10명 작고 뭉침 + 몬스터 작고 흐림 + 이펙트 없음 + 데미지 92,34 가독성 0 + 원형 빛 너무 크고 밋밋

extends Node2D

# === 문제점 7가지 ===
# 1. Texture Import: Filter On + Mipmap On + Compress Lossy -> 흐림
# 2. Viewport: 1920x1080인데 1280x720으로 스케일링 + stretch mode viewport -> 흐림
# 3. Camera: Zoom 1.0인데 10명 담으려고 멀리, 캐릭터 32px로 작게 보임
# 4. Lighting: DirectionalLight 없음 + Shadow 없음 + PBR 없음 -> 평면
# 5. VFX: Trail + Flash + Particles + Shake 없음 -> 타격감 0
# 6. Damage Popup: Font 10px + outline 없음 + 색 #999 -> 가독성 0
# 7. Circle VFX: 단순 Line2D + glow 없음 + moss/bronze 없음 -> 밋밋

# === 고치는 코드 ===

func _ready():
    fix_import_settings()
    fix_viewport()
    fix_camera()
    fix_lighting()
    fix_vfx()
    fix_damage_popup()
    fix_circle_vfx()
    fix_hero_scale()

func fix_import_settings():
    # ProjectSettings + Import Dock에서
    # 1. Filter: Off (2D 픽셀 아트 아니면 Off, 원화면 Off)
    # 2. Mipmap: Off (2D에서는 Off, 흐림 방지)
    # 3. Compress: Lossless or VRAM Uncompressed (Lossy 하면 흐림, 특히 영웅 얼굴)
    # 4. Fix: 모든 영웅/몬스터/석판 texture 재import
    # Godot -> Import 탭 -> Filter Off, Mipmap Off, Compress Lossless -> Reimport
    print("Import Fix: Filter Off, Mipmap Off, Compress Lossless")

func fix_viewport():
    # ProjectSettings -> Display -> Window
    # viewport_width = 1920, viewport_height = 1080
    # Window -> Stretch -> Mode = canvas_items, Aspect = keep
    # 1280x720 -> 1920x1080으로, 32px 캐릭터가 48px로 커짐, 선명도 2배
    get_window().content_scale_size = Vector2i(1920, 1080)
    get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
    get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP

func fix_camera():
    # 10명 원형 80px -> 120px로 키우고, Camera Zoom 1.0 -> 1.3, 캐릭터 32px -> 48px
    var camera = $Camera2D
    camera.zoom = Vector2(1.3, 1.3) # 1.0 -> 1.3, 30% 확대, 캐릭터 커짐
    camera.position = Vector2(0, -20) # 살짝 위에서 내려다보기, 깊이감
    # 10명 원형 반경 80 -> 120, 겹치지 않게
    for i in range($Heroes.get_child_count()):
        var hero = $Heroes.get_child(i)
        var angle = deg_to_rad(i * 36)
        hero.position = Vector2(cos(angle), sin(angle)) * 120 # 80->120

func fix_lighting():
    # DirectionalLight2D + Shadow + PBR
    var light = DirectionalLight2D.new()
    light.energy = 0.85
    light.color = Color(1, 1, 1)
    light.shadow_enabled = true
    light.shadow_filter = DirectionalLight2D.SHADOW_FILTER_PCF5
    light.shadow_color = Color(0,0,0,0.3)
    add_child(light)
    
    # PBR Stone
    var stone_mat = ShaderMaterial.new()
    stone_mat.shader = preload("res://shaders/PBR_Stone_Moss_Bronze.gdshader")
    stone_mat.set_shader_parameter("roughness", 0.58)
    stone_mat.set_shader_parameter("metallic", 0.32)
    stone_mat.set_shader_parameter("patina", 0.18)
    stone_mat.set_shader_parameter("moss", 0.12)
    $TileMap.material = stone_mat

func fix_vfx():
    # Trail + Flash + Particles + Shake
    # 영웅 공격 시 trail 0.15s + 잔상 2개 + white flash 0.04s + 파티클 6개 + shake 2px
    for hero in $Heroes.get_children():
        var trail = preload("res://scenes/Trail.tscn").instantiate()
        hero.add_child(trail)
    
    # Hit
    for monster in $Monsters.get_children():
        monster.hit_particles = preload("res://scenes/HitParticles.tscn").instantiate()
        monster.add_child(monster.hit_particles)

func fix_damage_popup():
    # Damage 92,34 가독성 0 -> Outfit 800 19px + outline 3px + bronze #C4A484 + crit scale 1.45 + y -48px
    var popup_settings = {
        "font": preload("res://fonts/Outfit-ExtraBold.ttf"),
        "font_size": 19,
        "outline_size": 3,
        "outline_color": Color(0,0,0,0.8),
        "color_normal": Color(0.847, 0.835, 0.8), # parchment #D8D5CC
        "color_crit": Color(0.768, 0.643, 0.517), # bronze #C4A484
        "scale_crit": 1.45,
        "y_offset": -48,
        "duration": 0.70
    }
    # DamagePopup.tscn에서 Label 설정 변경

func fix_circle_vfx():
    # 원형 빛 너무 크고 밋밋 -> moss #A8B89E + bronze #C4A484 + inner glow + rune 8개 + rotation 0.15 rad/s + particles
    var circle = $CircleVFX
    circle.material = ShaderMaterial.new()
    circle.material.shader = preload("res://shaders/Circle_Moss_Bronze.gdshader")
    circle.material.set_shader_parameter("color1", Color(0.658, 0.721, 0.619)) # moss
    circle.material.set_shader_parameter("color2", Color(0.768, 0.643, 0.517)) # bronze
    circle.material.set_shader_parameter("glow", 0.35)
    circle.material.set_shader_parameter("rotation_speed", 0.15)
    # Rune 8개
    for i in range(8):
        var rune = Sprite2D.new()
        rune.texture = preload("res://textures/rune_%d.png" % i)
        rune.position = Vector2(cos(i*PI/4), sin(i*PI/4)) * 100
        circle.add_child(rune)

func fix_hero_scale():
    # 영웅 10명 작고 뭉침 -> Scale 1.0 -> 1.5, Shadow + Breathing + Secondary
    for hero in $Heroes.get_children():
        hero.scale = Vector2(1.5, 1.5) # 1.0->1.5, 50% 확대
        # Breathing 2.0s 1.5px + Shadow y 연동 + Cape Secondary 5점 체인
        var breathing = preload("res://scripts/Breathing_Commercial.gd").new()
        breathing.breathe_time = 2.0
        breathing.breathe_scale = 0.03
        hero.add_child(breathing)
